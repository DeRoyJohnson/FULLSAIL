//DeRoy Johnson September 25, 2014 Functions Personal

var childAge = 2 //Child's Age
var babyMoney = 20 //Money able to spend for the baby milk powder container
var babypowderPyramid = function(length, width, height){

	var volume = (length * width * height) / 3;
	return volume;
}

var bkv = babypowderPyramid(4, 5, 3);
var bkv2 = babypowderPyramid(6, 5, 5);

if(bkv < 10 && babyMoney > 20 || childAge < 1){
	//If the powder level is lower than 10 cubic inches in the pyramid and you have more than $20, or your child is less than 1 years old you need to purchase more milk to fill the pyramid!
	console.log("Your child is still an infant and feeds more than toddlers, you need to purchase more baby milk powder to fill your " + bkv + " cubic inch pyramid container!");
}else if(bkv > 15 && babyMoney < 20|| childAge === 1){
	//If the powder level is higher than 10 cubic inches in the pyramid and you have less than $20, or your child is 1 years old! You can pass on purchasing baby milk powder!
	console.log("Yes, you can pass on spending on baby milk powder this week!") 
}
else(childAge > 1 ) ?
	//If the child is older than 1 years old you need to purchase the bigger pyramid container which is recommended for that age & above! If not refer to the age and volume requirements!



