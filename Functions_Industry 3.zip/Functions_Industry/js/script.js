//DeRoy Johnson September 25, 2014 Functions Industry



var beerKegVol = function(pi, radius, height){

	var volume = pi * Math.pow(radius, 2) * height;
	return volume;
}

