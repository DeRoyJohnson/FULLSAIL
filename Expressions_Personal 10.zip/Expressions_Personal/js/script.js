// De'Roy Johnson, September 11, 2011, Expressions Personal

var cWeight = prompt("How much do you weigh after completing the 3 month program? \nWe will calculate the average amount of weight you gained per month, as well as how much you would weigh if you continued this program.\nEnter whole numbers only!");

var lastWeight = prompt("Enter your last weight. \nWe will use this to calculate how much weight you gained all together. \nEnter whole numbers only!")

var data = [ cWeight, lastWeight, futureWeight ];
var all = data[0] - data[1];
var months3 = all/3;
var cWeight = data[0] + data [1];
var futureWeight = cWeight + all;
var a = 11;
var b = 9;




