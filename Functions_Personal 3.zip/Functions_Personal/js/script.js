//DeRoy Johnson September 25, 2014 Functions Personal

var childAge = 2 //Child's Age
var babyMoney = 20 //Money able to spend for the baby milk powder container
var babypowderPyramid = function(length, width, height){

	var volume = (length * width * height) / 3;
	return volume;
}

var bkv