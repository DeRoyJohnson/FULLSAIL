//DeRoy Johnson September 25, 2014 Functions Wacky

function clownShoes(){
	var clownShoes = (60 * .0825) + 60;//cost times the tax rate in Texas
	var cost = clownShoes;
	