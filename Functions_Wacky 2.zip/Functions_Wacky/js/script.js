//DeRoy Johnson September 25, 2014 Functions Wacky

function clownShoes(){
	var clownShoes = 
