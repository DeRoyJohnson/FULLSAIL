//DeRoy Johnson September 25, 2014 Functions Wacky

function clownShoes(){
	var clownShoes = (60 * .0825) + 60;//cost times the tax rate in Texas
	var cost = clownShoes;
	console.log("The clown shoes you need to be able to perform at the circus will cost $" + cost + ", and will be deducted from your check!")
	
	
}

clownShoes();
