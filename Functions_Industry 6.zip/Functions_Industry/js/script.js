//DeRoy Johnson September 25, 2014 Functions Industry



var beerKegVol = function(pi, radius, height){// parameters
//Beer Keg Volume 
	var volume = pi * Math.pow(radius, 2) * height;//formula for cylinder volume
	return volume;
}

var bkv = beerKegVol(3.14, 2, 4);//the values for the beer keg dimensions

console.log("The keg contains " + bkv + " cubic feet of beer!");
