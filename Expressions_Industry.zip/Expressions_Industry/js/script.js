//DeRoy Johnson, September 11, 2014, Expressions Industry

var parkLength = prompt("Whats the parks length in feet? \nSo we can calculate a park double and triple the size!");

var parkWidth = prompt("Whats the parks width in feet? \nSo we can calculate a park double and triple the size!")

var parkArea = parkWidth * parkLength;
var park2 = parkArea * 2;
var park3 = parkArea * 3;


alert("The parks area is " + parkArea + " sqft. If you want to have a park double this size, the area would be " + park2 + " sqft. However a park triple the original park would be " + park3 + " sqft.")
