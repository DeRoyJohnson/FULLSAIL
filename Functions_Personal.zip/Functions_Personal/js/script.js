//DeRoy Johnson September 25, 2014 Functions Personal

var childAge = 2 //Child's Age
var babyMoney = 